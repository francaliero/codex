
document.getElementById('reservaForm').addEventListener('submit', function(e) {
  e.preventDefault();
  const adultos = parseInt(document.getElementById('adultos').value);
  const ninos = parseInt(document.getElementById('ninos').value);
  const nombre = document.getElementById('nombre').value;
  const email = document.getElementById('email').value;
  const telefono = document.getElementById('telefono').value;

  let individuales = 0, dobles = 0, triples = 0;
  let adultosRestantes = adultos;
  let ninosRestantes = ninos;

  while (adultosRestantes >= 2) {
    dobles++;
    adultosRestantes -= 2;
  }
  while (adultosRestantes >= 1 && ninosRestantes >= 1) {
    dobles++;
    adultosRestantes--;
    ninosRestantes--;
  }
  while (adultosRestantes >= 1) {
    individuales++;
    adultosRestantes--;
  }
  while (ninosRestantes >= 2) {
    triples++;
    ninosRestantes -= 2;
    if (adultos > 0) {
      adultos--;
    }
  }

  let precio = individuales * 35 + dobles * 30 * 2 + triples * (30 + 20 * 2);
  let resumen = `
    <h3>Resumen de Reserva</h3>
    <p>Nombre: ${nombre}</p>
    <p>Email: ${email}</p>
    <p>Teléfono: ${telefono}</p>
    <p>Canoas individuales: ${individuales}</p>
    <p>Canoas dobles: ${dobles}</p>
    <p>Canoas triples: ${triples}</p>
    <p><strong>Precio total: ${precio} €</strong></p>
  `;
  document.getElementById('resumen').innerHTML = resumen;
});
